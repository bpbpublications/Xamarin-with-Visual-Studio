﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Brushes_Shapes_Media.Brushes
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RadialGradientPage : ContentPage
    {
        public RadialGradientPage()
        {
            InitializeComponent();
        }
    }
}