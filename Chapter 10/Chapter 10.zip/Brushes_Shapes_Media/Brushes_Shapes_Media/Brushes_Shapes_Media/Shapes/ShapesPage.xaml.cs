﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Shapes;
using Xamarin.Forms.Xaml;

namespace Brushes_Shapes_Media.Shapes
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ShapesPage : ContentPage
    {
        public ShapesPage()
        {
            InitializeComponent();
        }
    }
}