﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepository bookRepository;

        public BooksController(IBookRepository _bookRepository)
        {
            bookRepository = _bookRepository;
        }

        [HttpGet]
        public IActionResult List()
        {
            try
            {
                return Ok(bookRepository.All);
            }
            catch (Exception)
            {

                return BadRequest(ErrorCodes.CouldNotGetItems.ToString());
            }
        }

        [HttpPost]
        public IActionResult Create([FromBody] Book item)
        {
            try
            {
                if (item == null || !ModelState.IsValid)
                {
                    return BadRequest(ErrorCodes.InvalidBookData.ToString());
                }
                bool itemExists = bookRepository.DoesItemExist(item.ID);
                if (itemExists)
                {
                    return StatusCode(StatusCodes.Status409Conflict, ErrorCodes.BookIDInUse.ToString());
                }
                bookRepository.Insert(item);
            }
            catch (Exception)
            {
                return BadRequest(ErrorCodes.CouldNotCreateItem.ToString());
            }
            return Ok(item);
        }

        [HttpPut]
        public IActionResult Edit([FromBody] Book item)
        {
            try
            {
                if (item == null || !ModelState.IsValid)
                {
                    return BadRequest(ErrorCodes.InvalidBookData.ToString());
                }
                var existingItem = bookRepository.Find(item.ID);
                if (existingItem == null)
                {
                    return NotFound(ErrorCodes.RecordNotFound.ToString());
                }
                bookRepository.Update(item);
            }
            catch (Exception)
            {
                return BadRequest(ErrorCodes.CouldNotUpdateItem.ToString());
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                var item = bookRepository.Find(id);
                if (item == null)
                {
                    return NotFound(ErrorCodes.RecordNotFound.ToString());
                }
                bookRepository.Delete(id);
            }
            catch (Exception)
            {
                return BadRequest(ErrorCodes.CouldNotDeleteItem.ToString());
            }
            return NoContent();
        }
    }
}
