﻿namespace BookService
{
    public class Book
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public DateTime PublicationDate { get; set; }
        public string ISBN { get; set; }
    }
}
