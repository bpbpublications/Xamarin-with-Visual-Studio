﻿namespace BookService
{
    public class BookRepository : IBookRepository
    {
        private List<Book> Books;
        public IEnumerable<Book> All => Books;

        public BookRepository()
        {
            InitializeData(); 
        }
        public void Delete(int id)
        {
            Books.Remove(this.Find(id));
        }

        public bool DoesItemExist(int id)
        {
            return Books.Any(item => item.ID == id);
        }

        public Book Find(int id)
        {
            return Books.FirstOrDefault(item => item.ID == id);
        }

        public void Insert(Book item)
        {
            Books.Add(item);
        }

        public void Update(Book item)
        {
            var book = this.Find(item.ID);
            var index = Books.IndexOf(book);
            Books.RemoveAt(index);
            Books.Insert(index, item);
        }

        private void InitializeData()
        {
            Books = new List<Book>();
            var book1 = new Book
            {
                ID = 1,
                ISBN = "9789391392871",
                Title = "Practitioner’s Guide to Data Science",
                PublicationDate = new DateTime(2022, 1, 1)
            };

            var book2 = new Book
            {
                ID = 2,
                ISBN = "9789355510068",
                Title = "IoT for Beginners",
                PublicationDate = new DateTime(2021, 12, 1)
            };

            var book3 = new Book
            {
                ID = 3,
                ISBN = "9789355511102",
                Title = "iOS 15 Application Development for Beginners",
                PublicationDate = new DateTime(2021, 12, 1)
            };

            Books.Add(book1);
            Books.Add(book2);
            Books.Add(book3);
        }
    }
}
