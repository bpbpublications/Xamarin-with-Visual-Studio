﻿namespace BookService
{
    public enum ErrorCodes
    {
        InvalidBookData,
        BookIDInUse,
        RecordNotFound,
        CouldNotCreateItem,
        CouldNotUpdateItem,
        CouldNotDeleteItem,
        CouldNotGetItems
    }
}
