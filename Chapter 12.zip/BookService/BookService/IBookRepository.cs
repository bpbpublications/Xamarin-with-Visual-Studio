﻿namespace BookService
{
    public interface IBookRepository
    {
        bool DoesItemExist(int id);
        IEnumerable<Book> All { get; }
        Book Find(int id);
        void Insert(Book item);
        void Update(Book item);
        void Delete(int id);
    }
}
