﻿using BookClient.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace BookClient.ViewModel
{
    public class BookViewModel : NotifyBase
    {
        private ObservableCollection<Book> _books;

        public ObservableCollection<Book> Books
        {
            get { return _books; }
            set { _books = value; OnPropertyChanged(); }
        }

        public BookViewModel()
        {
            Books = new ObservableCollection<Book>();
        }

        private Book _selectedBook;
        public Book SelectedBook
        {
            get { return _selectedBook; }
            set { _selectedBook = value; OnPropertyChanged(); }
        }

        private const string baseAddress = "https://bookservice20220119123028.azurewebsites.net/api/books";

        public Command AddCommand
        {
            get
            {
                return new Command(async () =>
                {
                    var newBook = new Book();
                    newBook.ID = Books.Max(b => b.ID) + 1;
                    Books.Add(newBook);
                    await PostBookAsync(newBook);
                });
            }
        }

        public Command DeleteCommand
        {
            get
            {
                return new Command(async () =>
                {
                    Books.Remove(SelectedBook);
                    await DeleteBookAsync(SelectedBook);
                });
            }
        }

        public Command UpdateCommand
        {
            get
            {
                return new Command(async () =>
                {
                    await PutBookAsync(SelectedBook);
                });
            }
        }


        public async Task GetBooksAsync()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                var result = await client.GetAsync(client.BaseAddress);
                
                if (result.IsSuccessStatusCode)
                {
                    var resultContent = await result.Content.ReadAsStringAsync();

                    var deserializedBooks = JsonConvert.DeserializeObject<List<Book>>(resultContent);
                    foreach (var book in deserializedBooks)
                    {
                        Books.Add(book);
                    }
                }
            }
        }

        public async Task PostBookAsync(Book data)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                string json = JsonConvert.SerializeObject(data);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var result = await client.PostAsync(client.BaseAddress, content);
            }
        }

        public async Task PutBookAsync(Book data)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                string json = JsonConvert.SerializeObject(data);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var result = await client.PutAsync(client.BaseAddress, content);
            }
        }

        public async Task DeleteBookAsync(Book data)
        {
            Books.Remove(data);

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseAddress);
                string json = JsonConvert.SerializeObject(data, Formatting.None);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var result = await client.DeleteAsync($"{client.BaseAddress}/{data.ID}");

                var a = result.StatusCode;
            }
        }
    }
}
