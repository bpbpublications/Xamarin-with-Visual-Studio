﻿using BookClient.ViewModel;
using Xamarin.Forms;

namespace BookClient
{
    public partial class MainPage : ContentPage
    {
        private BookViewModel ViewModel { get; set; }
        public MainPage()
        {
            InitializeComponent();

            ViewModel = new BookViewModel();
            BindingContext = ViewModel;
            BookList.ItemsSource = ViewModel.Books;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await ViewModel.GetBooksAsync();

        }

    }
}
