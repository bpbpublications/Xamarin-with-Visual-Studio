﻿using System;

namespace BookClient.Model
{
    public class Book : NotifyBase
    {
        private int _id;
        public int ID
        {
            get { return _id; }
            set { _id = value; OnPropertyChanged(); }
        }
        private string _title;
        public string Title
        {

            get { return _title; }
            set
            {
                _title = value; OnPropertyChanged();
            }
        }
        private DateTime _publicationDate;
        public DateTime PublicationDate
        {
            get { return _publicationDate; }
            set { _publicationDate = value; OnPropertyChanged(); }
        }
        private string _isbn;
        public string ISBN
        {
            get { return _isbn; }
            set { _isbn = value; OnPropertyChanged(); }
        }

        public Book()
        {
            PublicationDate = DateTime.Today;
        }
    }
}
