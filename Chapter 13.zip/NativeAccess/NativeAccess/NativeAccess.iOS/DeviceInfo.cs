﻿using Foundation;

namespace NativeAccess.iOS
{
    public class DeviceInfo : IDeviceInfo
    {
        public string GetSystemLanguage()
        {
            return NSLocale.PreferredLanguages[0];
        }
    }
}