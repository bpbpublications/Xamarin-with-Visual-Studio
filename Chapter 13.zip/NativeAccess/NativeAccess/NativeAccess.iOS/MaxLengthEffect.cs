﻿using Foundation;
using NativeAccess.iOS;
using System;
using System.Linq;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ResolutionGroupName("MyCompanyName")]
[assembly: ExportEffect(typeof(MaxLengthEffectPlatform), "MaxLengthEffect")]
namespace NativeAccess.iOS
{
    public class MaxLengthEffectPlatform : PlatformEffect
    {
        protected override void OnAttached()
        {
            try
            {
                var sharedEffect = (MaxLengthEffect)Element.Effects.FirstOrDefault(e => e is MaxLengthEffect);

                UITextField nativeEntryView = Control as UITextField;
                if (nativeEntryView != null)
                {
                    nativeEntryView.ShouldChangeCharacters = (UITextField textField, 
                        NSRange range, string replacementString) =>
                    {
                        var length = textField.Text.Length - range.Length + replacementString.Length;
                        return length <= sharedEffect.MaxLength;
                    };
                }
            }
            catch (Exception ex)
            {
                //Catch any exception
            }
        }
        protected override void OnDetached()
        {
        }
    }
}