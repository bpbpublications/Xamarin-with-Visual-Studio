﻿using NativeAccess;
using NativeAccess.iOS;
using System.ComponentModel;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(BorderlessEntry), typeof(BorderlessEntryRenderer))]
namespace NativeAccess.iOS
{
    public class BorderlessEntryRenderer : EntryRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);
            if (Control != null)
            {
                // Clips sublayers to the bounds of the root layer of the view
                Control.Layer.MasksToBounds = true;
                // No corner radius
                Control.Layer.CornerRadius = 0;
                // No border
                Control.BorderStyle = UITextBorderStyle.None;
                // Minimum border width
                Control.Layer.BorderWidth = 1;
                // Assign transparent colours
                Control.Layer.BorderColor = Color.Transparent.ToCGColor();
            }
        }
    }
}