﻿using Android.Widget;
using NativeAccess;
using NativeAccess.Droid;
using System;
using System.Linq;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ResolutionGroupName("MyCompanyName")]
[assembly: ExportEffect(typeof(MaxLengthEffectPlatform), nameof(MaxLengthEffect))]
namespace NativeAccess.Droid
{
    public class MaxLengthEffectPlatform : PlatformEffect
    {
        protected override void OnAttached()
        {
            try
            {
                var sharedEffect = (MaxLengthEffect)Element.Effects.FirstOrDefault(e => e is MaxLengthEffect);

                TextView editEntry = Control as TextView;
                editEntry?.SetFilters(new Android.Text.IInputFilter[]
                {
                    new Android.Text.InputFilterLengthFilter(sharedEffect.MaxLength)
                });
            }
            catch (Exception ex)
            {
                //Catch any exception
            }
        }

        protected override void OnDetached()
        {

        }

    }
}