﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace NativeAccess
{
    public class MaxLengthEffect : RoutingEffect
    {
        public MaxLengthEffect() : base($"MyCompanyName.{nameof(MaxLengthEffect)}")
        {
        }

        public int MaxLength { get; set; }  
    }
}
