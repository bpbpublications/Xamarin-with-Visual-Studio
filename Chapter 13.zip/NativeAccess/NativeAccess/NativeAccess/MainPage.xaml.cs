﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace NativeAccess
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            
            Device.StartTimer(TimeSpan.FromSeconds(30), ShowMessage);            
        }


        private bool ShowMessage()
        {
            DisplayAlert("Info", "30 seconds have passed", "OK");
            return true;
        }

        private async void CultureInfoButton_Clicked(object sender, EventArgs e)
        {
            string osLanguage = DependencyService.Get<IDeviceInfo>().GetSystemLanguage();
            await DisplayAlert("Info", osLanguage, "OK");
        }
    }
}
