﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Essentials;
using System.IO;

namespace XamarinEssentials
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            Connectivity.ConnectivityChanged += Connectivity_ConnectivityChanged;
            MessagingCenter.Subscribe<App, bool>(this, "BatteryEvent",
                                     ManageBatteryLevelChanged);

        }

        private void ManageBatteryLevelChanged(App arg1, bool arg2)
        {
            // Save data or generally prevent data loss
        }

        private async void Connectivity_ConnectivityChanged
            (object sender, ConnectivityChangedEventArgs e)
        {
            switch (e.NetworkAccess)
            { 
                case NetworkAccess.Internet:
                    // App is connected to the Internet:
                    break;
                case NetworkAccess.Local:
                    // App is connected to a local newtwork
                    break;
                case NetworkAccess.ConstrainedInternet:
                    // App has limited connection to the Internet
                    break;
                case NetworkAccess.None:
                    // App is not connected
                    break;
                default:  // Unknown
                    break;
            }


            if (e.NetworkAccess != NetworkAccess.Internet)
            {
                await DisplayAlert("Warning", "Limited internet connection", "OK");
                // Do additional work to limit network access...
            }
        }

        public async Task SendSms(string messageText, string[] recipients)
        {
            var message = new SmsMessage(messageText, recipients);
            await Sms.ComposeAsync(message);
        }

        private async Task OpenBrowser()
        {
            await Browser.OpenAsync("https://www.microsoft.com");
        }

        private async Task OpenLauncher()
        {
            string uri = "mailto://somebody@something.com";
            bool canOpen = await Launcher.CanOpenAsync(uri);
            if(canOpen)
                await Launcher.OpenAsync("mailto://somebody@something.com");
        }

        private void CheckNetworkConnection()
        {
            if(Connectivity.NetworkAccess != NetworkAccess.None)
            {
                // Internet is available

                var profiles = Connectivity.ConnectionProfiles;
                if(profiles.Contains(ConnectionProfile.WiFi) || 
                    profiles.Contains(ConnectionProfile.Ethernet))
                {
                    // Ethernet or WiFi connection, all good
                }
                else if(profiles.Contains(ConnectionProfile.Cellular))
                {
                    // Inform the user about possible charges of their data plan
                }
                else if (profiles.Contains(ConnectionProfile.Bluetooth))
                {
                    // Bluetooth is also available
                }
                else
                {
                    // Handle unknown status
                }
            }
        }

        private async void EmailButton_Clicked(object sender, EventArgs e)
        {
            EmailMessage message = new EmailMessage();
            message.Subject = "Contact request";
            message.To = new List<string> { "support@yourcompany.com" };
            message.Cc = new List<string> { "marketing@mycompany.com" };
            message.BodyFormat = EmailBodyFormat.PlainText;
            message.Body = "We would need to meet your developers to suggest features.";

            string attachmentPath = Path.Combine(Environment.GetFolderPath(
                                    Environment.SpecialFolder.MyPictures), 
                                    "attachedImage.jpg");
            EmailAttachment attachment = new EmailAttachment(attachmentPath);
            message.Attachments = new List<EmailAttachment>();
            message.Attachments.Add(attachment);

            await Email.ComposeAsync(message);
        }

        private void SensSms()
        {
            var message = new SmsMessage();
            message.Body = "Text of the message";
            message.Recipients = new List<string>{"Alessandro Del Sole"};
            Sms.ComposeAsync(message);
        }

        private async void OpenContentAsync()
        {
            string url = "https://www.someproducts.com/usermanual.pdf";
            if(await Launcher.CanOpenAsync(url))
                await Launcher.OpenAsync(url);
        }

        private void SaveSettings()
        {
            // Stores an integer
            Preferences.Set("NumberOfTapsPerAction", 2);
            // Stores a DateTime
            Preferences.Set("LastDateTimeAccess", DateTime.Now);

            // Checks if the key exist
            if (Preferences.ContainsKey("NumberOfTapsPerAction"))
                // Returns the value for the key, and a default value
                // if the key is not found
                Preferences.Get("NumberOfTapsPerAction", 0);

            // Remove an individual key
            Preferences.Remove("NumberOfTapsPerAction");
            // Remove all preferences
            Preferences.Clear();
        }

        private async Task SecureSettingsAsync()
        {
            // Add a key/value pair to the secure storage
            await SecureStorage.SetAsync("UserID", "123456");
            

            // Get a key/value pair from the secure storage
            string userIDValue = await SecureStorage.GetAsync("UserID");

            // Removes the specified key from the secure storage
            SecureStorage.Remove("UserID");
        }

        private async Task<bool> IsAppRunningForFirstTime()
        {
            if (VersionTracking.IsFirstLaunchEver)
            {
                string userID = await SecureStorage.GetAsync("userID");
                if (userID != null)
                    SecureStorage.Remove("userID");
                return true;
            }

            return false;
        }
    }
}
