﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Xamarin.Essentials;
namespace XamarinEssentials
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            Battery.EnergySaverStatusChanged += Battery_EnergySaverStatusChanged;
            
            MainPage = new MainPage();
        }

        private void Battery_EnergySaverStatusChanged(object sender, EnergySaverStatusChangedEventArgs e)
        {
            MessagingCenter.Send(this, "BatteryEvent", e.EnergySaverStatus ==
                                 EnergySaverStatus.On && Battery.ChargeLevel <= 0.2);

        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
